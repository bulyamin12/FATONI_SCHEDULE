from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.db import models

hex_color = RegexValidator(r"^#[0-9a-fA-F]{6}$", "สีต้องเป็นรหัส Hex เช่น #1e90ff")


class Faculty(models.Model):
    """คณะ พร้อมสีประจำคณะสำหรับแท็กบนปฏิทิน"""

    name = models.CharField("ชื่อคณะ", max_length=150, unique=True)
    color = models.CharField(
        "สีประจำคณะ", max_length=7, default="#1e90ff", validators=[hex_color]
    )

    class Meta:
        verbose_name = "คณะ"
        verbose_name_plural = "คณะ"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Department(models.Model):
    """ภาควิชา อยู่ภายใต้คณะ"""

    faculty = models.ForeignKey(
        Faculty,
        on_delete=models.CASCADE,
        related_name="departments",
        verbose_name="คณะ",
    )
    name = models.CharField("ชื่อภาควิชา", max_length=150)

    class Meta:
        verbose_name = "ภาควิชา"
        verbose_name_plural = "ภาควิชา"
        ordering = ["faculty__name", "name"]
        constraints = [
            models.UniqueConstraint(
                fields=["faculty", "name"], name="unique_department_per_faculty"
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.faculty.name})"


class Event(models.Model):
    """กิจกรรมของมหาวิทยาลัย"""

    STATUS_CHOICES = [
        ("pending", "รออนุมัติ"),
        ("approved", "อนุมัติแล้ว"),
        ("rejected", "ไม่อนุมัติ"),
    ]

    title = models.CharField("ชื่อกิจกรรม", max_length=200)
    description = models.TextField("รายละเอียด", blank=True)
    location = models.CharField("สถานที่", max_length=200, blank=True)
    start_at = models.DateTimeField("เริ่มต้น")
    end_at = models.DateTimeField("สิ้นสุด")
    faculty = models.ForeignKey(
        Faculty,
        on_delete=models.PROTECT,
        related_name="events",
        verbose_name="คณะ",
    )
    department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="events",
        verbose_name="ภาควิชา",
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="schedule_events",
        verbose_name="ผู้สร้าง",
    )
    status = models.CharField(
        "สถานะ", max_length=10, choices=STATUS_CHOICES, default="pending"
    )
    created_at = models.DateTimeField("วันที่สร้าง", auto_now_add=True)

    class Meta:
        verbose_name = "กิจกรรม"
        verbose_name_plural = "กิจกรรม"
        ordering = ["start_at"]

    def __str__(self):
        return self.title

    def clean(self):
        # Validation: เวลาสิ้นสุดต้องหลังเวลาเริ่มต้น
        if self.start_at and self.end_at and self.end_at <= self.start_at:
            raise ValidationError("เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น")
        # Validation: ภาควิชาต้องอยู่ในคณะที่เลือก
        if self.department_id and self.faculty_id:
            if self.department.faculty_id != self.faculty_id:
                raise ValidationError("ภาควิชาที่เลือกไม่ได้อยู่ในคณะนี้")