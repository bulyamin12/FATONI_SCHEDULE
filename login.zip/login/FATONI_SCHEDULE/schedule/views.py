from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import EventForm
from .models import Department, Event, Faculty

# เข้าได้เฉพาะ Staff (ถ้าไม่ใช่จะถูกพาไปหน้า Login)
staff_required = user_passes_test(lambda u: u.is_staff, login_url="login")


def calendar_page(request):
    """หน้าปฏิทินกิจกรรม (ทุกคนดูได้)"""
    return render(request, "schedule/calendar.html", {"faculties": Faculty.objects.all()})


def event_feed(request):
    """ข้อมูลกิจกรรมเป็น JSON ให้ FullCalendar ดึงไปแสดง"""
    events = Event.objects.select_related("faculty")
    # คนทั่วไปเห็นเฉพาะกิจกรรมที่อนุมัติแล้ว แอดมินเห็นทั้งหมด
    if not request.user.is_staff:
        events = events.filter(status="approved")

    data = [
        {
            "id": e.pk,
            "title": e.title,
            "start": e.start_at.isoformat(),
            "end": e.end_at.isoformat(),
            "color": e.faculty.color,
            "url": f"/events/{e.pk}/",
        }
        for e in events
    ]
    return JsonResponse(data, safe=False)


def event_list(request):
    """รายการกิจกรรมที่อนุมัติแล้ว กรองตามคณะได้"""
    events = Event.objects.filter(status="approved").select_related("faculty", "department")

    faculty_id = request.GET.get("faculty", "")
    if faculty_id.isdigit():
        events = events.filter(faculty_id=int(faculty_id))

    context = {
        "events": events,
        "faculties": Faculty.objects.all(),
        "selected_faculty": faculty_id,
    }
    return render(request, "schedule/event_list.html", context)


def event_detail(request, pk):
    """รายละเอียดกิจกรรม (ที่ยังไม่อนุมัติ เห็นเฉพาะเจ้าของและแอดมิน)"""
    event = get_object_or_404(Event.objects.select_related("faculty", "department"), pk=pk)
    is_owner = request.user.is_authenticated and event.created_by_id == request.user.pk
    if event.status != "approved" and not (is_owner or request.user.is_staff):
        return render(request, "404.html", status=404)
    return render(request, "schedule/event_detail.html", {"event": event, "is_owner": is_owner})


@login_required
def my_events(request):
    """กิจกรรมของฉัน"""
    events = Event.objects.filter(created_by=request.user).select_related("faculty")
    return render(request, "schedule/my_events.html", {"events": events})


@login_required
def event_create(request):
    """เพิ่มกิจกรรม (แอดมินอนุมัติทันที ผู้ใช้ทั่วไปต้องรออนุมัติ)"""
    if request.method == "POST":
        form = EventForm(request.POST)
        if form.is_valid():
            event = form.save(commit=False)
            event.created_by = request.user
            event.status = "approved" if request.user.is_staff else "pending"
            event.save()
            if event.status == "pending":
                messages.success(request, "ส่งกิจกรรมแล้ว รอแอดมินอนุมัติ")
            else:
                messages.success(request, "เพิ่มกิจกรรมเรียบร้อยแล้ว")
            return redirect("my_events")
    else:
        form = EventForm()
    return render(request, "schedule/event_form.html", {"form": form, "title": "เพิ่มกิจกรรม"})


@login_required
def event_update(request, pk):
    """แก้ไขกิจกรรม (เจ้าของหรือแอดมินเท่านั้น)"""
    qs = Event.objects.all() if request.user.is_staff else Event.objects.filter(created_by=request.user)
    event = get_object_or_404(qs, pk=pk)

    if request.method == "POST":
        form = EventForm(request.POST, instance=event)
        if form.is_valid():
            updated = form.save(commit=False)
            # ผู้ใช้ทั่วไปแก้แล้วต้องให้แอดมินอนุมัติใหม่
            if not request.user.is_staff:
                updated.status = "pending"
            updated.save()
            messages.success(request, "บันทึกการแก้ไขแล้ว")
            return redirect("my_events")
    else:
        form = EventForm(instance=event)
    return render(request, "schedule/event_form.html", {"form": form, "title": "แก้ไขกิจกรรม"})


@login_required
@require_POST
def event_delete(request, pk):
    """ลบกิจกรรม (เจ้าของหรือแอดมินเท่านั้น)"""
    qs = Event.objects.all() if request.user.is_staff else Event.objects.filter(created_by=request.user)
    event = get_object_or_404(qs, pk=pk)
    event.delete()
    messages.success(request, "ลบกิจกรรมแล้ว")
    return redirect("my_events")


@staff_required
def manage_events(request):
    """แอดมินดูกิจกรรมทั้งหมดที่ผู้ใช้เพิ่ม"""
    events = Event.objects.select_related("faculty", "created_by").order_by("-created_at")
    return render(request, "schedule/manage_events.html", {"events": events})


@staff_required
@require_POST
def event_status(request, pk, action):
    """แอดมินอนุมัติหรือไม่อนุมัติกิจกรรม (action = approved / rejected)"""
    if action not in ("approved", "rejected"):
        return JsonResponse({"error": "action ไม่ถูกต้อง"}, status=400)
    event = get_object_or_404(Event, pk=pk)
    event.status = action
    event.save()
    messages.success(request, f"เปลี่ยนสถานะ '{event.title}' แล้ว")
    return redirect("manage_events")


def department_options(request, faculty_id):
    """ภาควิชาของคณะที่เลือก (JSON) ใช้กับ Dropdown ที่เปลี่ยนตามคณะ"""
    departments = Department.objects.filter(faculty_id=faculty_id).values("id", "name")
    return JsonResponse(list(departments), safe=False)


def register(request):
    """สมัครสมาชิก แล้ว Login ให้อัตโนมัติ"""
    if request.user.is_authenticated:
        return redirect("calendar")

    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "สมัครสมาชิกสำเร็จ")
            return redirect("calendar")
    else:
        form = UserCreationForm()
    return render(request, "registration/register.html", {"form": form})