from django.urls import path

from . import views

urlpatterns = [
    path("", views.calendar_page, name="calendar"),
    path("events/feed/", views.event_feed, name="event_feed"),
    path("events/", views.event_list, name="event_list"),
    path("events/mine/", views.my_events, name="my_events"),
    path("events/add/", views.event_create, name="event_create"),
    path("events/<int:pk>/", views.event_detail, name="event_detail"),
    path("events/<int:pk>/edit/", views.event_update, name="event_update"),
    path("events/<int:pk>/delete/", views.event_delete, name="event_delete"),
    path("events/<int:pk>/status/<str:action>/", views.event_status, name="event_status"),
    path("manage/", views.manage_events, name="manage_events"),
    path("faculties/<int:faculty_id>/departments/", views.department_options, name="department_options"),
    path("register/", views.register, name="register"),
]