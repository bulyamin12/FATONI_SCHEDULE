from django.contrib import admin

from .models import Department, Event, Faculty


@admin.register(Faculty)
class FacultyAdmin(admin.ModelAdmin):
    list_display = ("name", "color")
    search_fields = ("name",)


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("name", "faculty")
    list_filter = ("faculty",)
    search_fields = ("name",)


@admin.action(description="อนุมัติกิจกรรมที่เลือก")
def approve_events(modeladmin, request, queryset):
    queryset.update(status="approved")


@admin.action(description="ไม่อนุมัติกิจกรรมที่เลือก")
def reject_events(modeladmin, request, queryset):
    queryset.update(status="rejected")


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("title", "faculty", "department", "start_at", "end_at", "status", "created_by")
    list_filter = ("status", "faculty", "start_at")
    search_fields = ("title", "description", "location")
    ordering = ("-start_at",)
    actions = [approve_events, reject_events]