from django import forms

from .models import Event

DATETIME_FORMAT = "%Y-%m-%dT%H:%M"


class EventForm(forms.ModelForm):
    """ฟอร์มเพิ่ม/แก้ไขกิจกรรม (Validation อยู่ใน Model.clean)"""

    class Meta:
        model = Event
        fields = (
            "title",
            "description",
            "location",
            "start_at",
            "end_at",
            "faculty",
            "department",
        )
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "location": forms.TextInput(attrs={"class": "form-control"}),
            "start_at": forms.DateTimeInput(
                format=DATETIME_FORMAT,
                attrs={"class": "form-control", "type": "datetime-local"},
            ),
            "end_at": forms.DateTimeInput(
                format=DATETIME_FORMAT,
                attrs={"class": "form-control", "type": "datetime-local"},
            ),
            "faculty": forms.Select(attrs={"class": "form-select"}),
            "department": forms.Select(attrs={"class": "form-select"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # รับรูปแบบวันเวลาจากช่อง datetime-local ของเบราว์เซอร์
        self.fields["start_at"].input_formats = [DATETIME_FORMAT]
        self.fields["end_at"].input_formats = [DATETIME_FORMAT]
        self.fields["department"].required = False
        self.fields["department"].empty_label = "- ไม่ระบุภาควิชา -"