// สร้างปฏิทินด้วย FullCalendar และดึงกิจกรรมจาก /events/feed/ (JSON)
document.addEventListener("DOMContentLoaded", function () {
    const el = document.getElementById("calendar");
    if (!el) return;

    const calendar = new FullCalendar.Calendar(el, {
        initialView: "dayGridMonth",
        locale: "th",
        height: "auto",
        headerToolbar: {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,listMonth",
        },
        buttonText: {
            today: "วันนี้",
            month: "เดือน",
            week: "สัปดาห์",
            list: "รายการ",
        },
        // URL ของข้อมูลกิจกรรม มาจาก data-feed ใน HTML (ไม่เขียนตายตัวในไฟล์ JS)
        events: el.dataset.feed,
        eventTimeFormat: { hour: "2-digit", minute: "2-digit", hour12: false },
        noEventsText: "ไม่มีกิจกรรม",
    });
    calendar.render();
});