from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    # login / logout สำเร็จรูปของ Django (ใช้ Template ที่ registration/login.html)
    path("accounts/", include("django.contrib.auth.urls")),
    path("", include("schedule.urls")),
]

# เสิร์ฟไฟล์ที่ผู้ใช้อัปโหลดตอนพัฒนา (DEBUG = True)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)