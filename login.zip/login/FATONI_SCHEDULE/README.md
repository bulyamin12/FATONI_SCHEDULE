# Fatoni University Activity Schedule System

Django web application for managing a university activity calendar.

## Features
- Register / Login / Logout (Django authentication)
- Authorization: guests view approved events; users add/edit/delete their own events; admin approves or rejects all events
- Calendar view (FullCalendar) with color tags per faculty

## Run
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```